/*
    Keenan Fiedler
    This is the client-side Javascript file for PA8. It allows the users text entered in the text boxes
    to be send to the server to be saved as users or items
*/

//This function sends the information necessary to add a user to the server
//It has no parameters
function addUser(){
    let inputs = document.getElementsByClassName("userItems");
    let send = {username: inputs[0].value, password: inputs[1].value};
    let p = fetch("http://localhost:80/add/user", {
        method: 'POST',
        body: JSON.stringify(send),
        headers: { 'Content-Type': 'application/json'}
    });
    p.catch((error) => {
        console.log(error);
    });
    console.log("Sent");
    inputs[0].value = "";
    inputs[1].value = "";
}


//This function sends the information necessary to add an item to the server
//It has no paramters
function addItem(){
    let inputs = document.getElementsByClassName("itemItems");
    console.log(inputs);
    let send = {title: inputs[0].value, 
                desc: inputs[1].value, 
                image: inputs[2].value, 
                price: inputs[3].value, 
                status: inputs[4].value};
    let p = fetch("http://localhost:80/add/item/" + inputs[5].value, {
        method: 'POST',
        body: JSON.stringify(send),
        headers: { 'Content-Type': 'application/json'}
    });
    p.catch((error) => {
        console.log(error);
    });
    console.log("Sent");
    for(let i = 0; i< inputs.length; i++){
        inputs[i].value = "";
    }
}