/*
    Keenan Fiedler
    This is the server Javascript file for PA8. It allows the input of the user in to add items and users.
    It also allows for several other methods through the urls to get information from the database
*/

//basic inclusion of packages
const express = require('express');
const mongoose = require('mongoose');
const parser = require('body-parser');

//DB stuff
const db = mongoose.connection;
const mongoDBURL = 'mongodb://127.0.0.1/ostaa';
mongoose.connect(mongoDBURL, {useNewURLParser: true});
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
var ObjectId = require('mongodb').ObjectId; 


//Setting up schema
var Schema = mongoose.Schema;
var userSchema = new Schema({
    username: String,
    password: String,
    listings: Object,
    purchases: Object
});
var user = mongoose.model('UserModel', userSchema );
var itemSchema = new Schema({
    title: String,
    desc: String,
    image: String,
    price: Number,
    status: String
});
var item = mongoose.model('ItemModel', itemSchema );


//starts server and listens for requests
//only takes URLS matching /translate/TYPE/CONTENT
const app = express();
app.use(parser.json());
const port = 80;
app.use(express.static('public_html'));
app.listen(port, () => console.log(`App listening at http://localhost:${port}`));
//compiles users from the database into a string
app.get('/get/users', function(req,res){
    let users = user.find({}).exec();
    var buffer = "";
    users.then((users) => {
        for(var i = 0; i < users.length; i++){
            buffer = buffer + users[i] +'\n';
        }
        res.end(buffer);
    });
});
//compiles items from the database into a string
app.get('/get/items', function(req,res){
    let items = item.find({}).exec();
    var buffer = "";
    items.then((items) => {
        for(var i = 0; i < items.length; i++){
            buffer = buffer + items[i] +'\n';
        }
        res.end(buffer);
    });
});
//compiles listings of a user from the database into a string
app.get('/get/listings/:USERNAME', function(req,res){
    let users = user.findOne({username: req.params.USERNAME}).exec();
    var buffer = "";
    users.then((users) => {
        if(users != null){
            let list = users.listings;
            var itemidlist = [];
            if(list != undefined){
                for(let i = 0; i < list.length; i++){
                    itemidlist[i] = new ObjectId(list[i]);
                }
                let items = item.find({_id: {$in: itemidlist}}).exec();
                items.then((items)=>{
                    for(let i =0; i<items.length; i++){
                        buffer = buffer + items[i] + "\n";
                    }
                }).then(()=>{
                    res.end(buffer);
                });
            }else{
                res.end("There are no items.");
            }
        }else{
            res.end("User does not exist");
        }
    });
});
//compiles purchases of a user from the database into a string
app.get('/get/purchases/:USERNAME', function(req,res){
    let users = user.findOne({username: req.params.USERNAME}).exec();
    var buffer = "";
    users.then((users) => {
        if(users != null){
            let list = users.purchases;
            var itemidlist = [];
            if(list != undefined){
                for(let i = 0; i < list.length; i++){
                    itemidlist[i] = new ObjectId(list[i]);
                }
                let items = item.find({_id: {$in: itemidlist}}).exec();
                items.then((items)=>{
                    for(let i =0; i<items.length; i++){
                        buffer = buffer + items[i] + "\n";
                    }
                }).then(()=>{
                    res.end(buffer);
                });
            }else{
                res.end("There are no purchases.");
            }
        }else{
            res.end("User does not exist");
        }  
    });
});
//compiles all users with substring from the database into a string
app.get('/search/users/:KEYWORD', function(req,res){
    regex = new RegExp(".*" + req.params.KEYWORD + ".*")
    let users = user.find({username: regex}).exec();
    var buffer = "";
    users.then((users) => {
        for(var i = 0; i < users.length; i++){
            buffer = buffer + users[i] + '\n';
        }
        res.end(buffer);
    });
});
//compiles all items with substring from the database into a string
app.get('/search/items/:KEYWORD', function(req,res){
    regex = new RegExp(".*" + req.params.KEYWORD + ".*")
    let items = item.find({desc: regex}).exec();
    var buffer = "";
    items.then((items) => {
        for(var i = 0; i < items.length; i++){
            buffer = buffer + items[i] + '\n';
        }
        res.end(buffer);
    });
});
//adds a user to the database
app.post('/add/user', function(req,res){
    let username = req.body.username;
    let password = req.body.password;
    let listings = [];
    let purchases = [];
    let send = new user({username: username, password: password, listings: listings, purchases: purchases});
    let p = send.save();
    p.then(() => {
        console.log("Saved User!")
    });
    p.catch((error) => {
        console.log('Save failed');
        console.log(error);
    });
    res.end();
});
//adds an item to the database
app.post('/add/item/:username', function(req,res){
    let title = req.body.title;
    let desc = req.body.desc;
    let image = req.body.image;
    let price = req.body.price;
    let status = req.body.status
    let username = req.params.username;
    console.log(title);
    let send = new item({title: title, desc: desc, image: image, price: price, status: status});
    let p = send.save();
    p.then(() => {
        console.log("Saved Item!")
    }).then(()=> {
        let Useritem = item.findOne({desc: desc});
        Useritem.then((Useritem) => {user.updateOne({username: username}, {$push: {"listings":Useritem.id}}).exec()});
    });
    p.catch((error) => {
        console.log('Save failed');
        console.log(error);
    });
    res.end();
});